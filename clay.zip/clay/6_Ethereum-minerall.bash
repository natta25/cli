./ethdcrminer64 -epool pool.minerall.io:3401 -ewal 0x360d6f9efea21c82d341504366fd1c2eeea8fa9d -eworker Claymore -epsw x -mode 1 -r 0 -dbg -1 -mport 0 -etha 0 -retrydelay 1 -ftime 55 -tt 79 -ttli 77 -tstop 89 -fanmin 30 -esm 3


