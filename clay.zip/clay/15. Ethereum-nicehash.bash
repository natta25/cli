./ethdcrminer64 -epool stratum+tcp://daggerhashimoto.eu-new.nicehash.com:3353 -ewal 1Pz3EcHsRuJkraNRACUrBrLaxiTPP1VHJZ -epsw x -dbg -1 -retrydelay 1 -ftime 55 -tt 79 -ttli 77 -tstop 89 -tstart 85 -fanmin 30 -r 0 -esm 3 -estale 0 -erate 1 -allpools 1


